# Mentorama Model API

Modelo treinado utilizando uma random forest. 

### Rotas
- POST
    ```/predict:``` versão final do modelo para previsão
        
        model inputs:
            -  X1: descrição da variável
            -  X2: descrição da variável
            -  X3: descrição da variável
            -  X4: descrição da variável
            -  X5: descrição da variável
        
        model output: 
        prediction: boolean 0 ou 1

- GET
    ```/model_health/<model_id>```: Metricas do modelo. Recall e Precision disponíveis. 
        
        model_id: id do modelo em produção